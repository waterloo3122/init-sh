This is a bare-bones readme file for the multi-file package.
