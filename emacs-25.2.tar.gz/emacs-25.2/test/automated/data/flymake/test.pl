@arr = [1,2,3,4];
my $b = @arr[1];
