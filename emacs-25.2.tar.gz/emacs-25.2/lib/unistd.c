#include <config.h>
#define _GL_UNISTD_INLINE _GL_EXTERN_INLINE
#include "unistd.h"
typedef int dummy;
